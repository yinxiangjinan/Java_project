package com.itheima;

public class JavaDemo03 {
  public static void main(String[] args) {
    String time = "2020-11-05 08:00:00";
      String[] s = time.split(" ");
    System.out.println(time.split(" ")[0].split("-")[0]+time.split(" ")[0].split("-")[1]+time.split(" ")[0].split("-")[2]+"_"+time.split(" ")[1]);
  }
}
