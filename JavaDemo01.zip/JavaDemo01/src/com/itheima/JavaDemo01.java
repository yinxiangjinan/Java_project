package com.itheima;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class JavaDemo01 {
  public static void main(String[] args) {
    String str =
        "["
            + "{'CREATE_TIME':'2020-11-05 08:00:00','AREA_ID':'QD','WEATHER':'阴','WINDDIREC':'南风','MIN_TEMPERATUR':'14','AREA_NANE':'青岛市','WINDLEVEL':'3到4级','ID':'B35395047DB32CE053e4318C0A79ED','AREA_CODE':'3702','FUTURE_HOUR':'24','MAX_TEMPERATUR':'16','COUNTRY':'青岛'},"
            + "{'CREATE_TIME':'2020-11-05 08:00:00','AREA_ID':'QD','WEATHER':'晴','WINDDIREC':'北风','MIN_TEMPERATUR':'9','AREA_NAME':'青岛市','WINDLEVEL':'3到4级','ID':'B35395047DB42CE053e4318C0A79ED','AREA_CODE':'3702','FUTURE_HOUR':'9','AREA_NAME':'青岛市','MAX_TEMPERATUR':'16','COUNTRY':'青岛'}"
            + "]";
    JSONArray jsonArray = JSONArray.parseArray(str);
    testOne(jsonArray);

  }

  private static void testOne(JSONArray jsonArray) {
  
    for (int i = 0; i < jsonArray.size(); i++) {
      JSONObject jsonObject = JSONObject.parseObject(jsonArray.get(i).toString());
      String create_time = jsonObject.get("CREATE_TIME").toString();
      System.out.println("create_time:" + create_time);
    }
  }
}
