package com.itheima;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sun.deploy.uitoolkit.impl.fx.AppletStageManager;

public class JavaDemo02 {
  public static void main(String[] args) {
      String str = "[{'name': 'Jerry','age': '123','id':'12'},{'name': 'Anne','age': '234','id': '456'}]";
      JSONArray jsonArray = JSONArray.parseArray(str);
    for (int i = 0; i < jsonArray.size(); i++) {
        JSONObject jsonObject = JSONObject.parseObject(jsonArray.get(i).toString());
      System.out.println(jsonObject.get("name"));
    }
  }
}
