package com.itheima;

public class JavaDemo07 {
  public static void main(String[] args) {
    String sql_name = "#8风机";
       // #A8风机
      String str = "#A8风机";
    System.out.println(str.substring(0,1));
    System.out.println(str.substring(0,1)+str.split("\\#")[1].substring(1));


  }
}
