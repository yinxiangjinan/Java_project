package com.itheima;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JavaDemo06 {
  public static void main(String[] args) throws ParseException {
      long startTime=System.currentTimeMillis();//记录开始时间

    System.out.println("Jerr");

      long endTime=System.currentTimeMillis();//记录结束时间

      float excTime=(float)(endTime-startTime)/1000;

      System.out.println("执行时间："+excTime+"s");
  }
}
