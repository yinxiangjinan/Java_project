package com.itheima;

public class JavaDemo04 {
  public static void main(String[] args) {
    String time = "2020-12-10 12:28:13";
    String[] t = time.split(" ");
    String[] split = t[0].split("-");
    System.out.println(split[0]+split[1]+split[2]+"_"+t[1]);
  }
}
